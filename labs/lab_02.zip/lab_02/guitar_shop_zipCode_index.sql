USE my_guitar_shop2;

CREATE INDEX zipCode ON addresses (zipCode);